// constants

export const INCREMENT="COUNTER.INCREMENT";
export const DECREMENT="COUNTER.DECREMENT";