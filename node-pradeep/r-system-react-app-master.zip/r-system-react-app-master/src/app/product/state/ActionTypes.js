export const INIT_ERROR = "PRODUCT.INIT_ERROR";
export const LOADING = "PRODUCT.LOADING";

//products list page
export const INIT_PRODUCTS = "PRODUCT.INIT_PRODUCTS";

export const EDIT_PRODUCT = "PRODUCT.EDIT_PRODUCT";



//saga example
export const FETCH_PRODUCTS = "PRODUCT.FETCH_PRODUCTS";