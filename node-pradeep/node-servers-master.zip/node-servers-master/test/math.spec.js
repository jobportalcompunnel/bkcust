describe('Math', function() {
    describe('add', function() {
      it('should add numbers without error', function() {

      });
    });
  });