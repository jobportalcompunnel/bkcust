# Pre-Requistes

1. Java 1.8
2. Scala 2.11.12 (Since Spark doesn't compiled with 2.12.x)
   this can be managed through sbt
   