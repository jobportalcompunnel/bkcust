echo "I ran! `date`" > /tmp/output
