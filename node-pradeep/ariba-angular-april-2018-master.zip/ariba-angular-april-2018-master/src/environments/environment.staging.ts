export const environment = {
  production: true,
  buildName: 'staging',
  // actual, qa1.example.com
  apiEndPoint: 'http://localhost:7070',
  authEndPoint: 'http://localhost:7070/oauth/token'
};
