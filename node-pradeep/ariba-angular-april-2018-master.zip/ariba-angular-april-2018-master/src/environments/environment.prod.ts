export const environment = {
  production: true,
  buildName: 'production',
  // actual, example.com
  apiEndPoint: 'http://localhost:7070',
  authEndPoint: 'http://localhost:7070/oauth/token'
};
