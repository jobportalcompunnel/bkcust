export class Address {
    // city: string;
    // state: string;
    // pincode: number;

    // constructor(city: string, 
    //             state: string, 
    //             pincode: number
    //         ) {
    //             this.city = city;
    //             this.state = state;
    //             this.pincode = pincode;
    //         }

    constructor(public city: string, 
                public state: string, 
                public pincode: number) {
                    
                }
}

// addr = new Address('BLR), 'KA');
// addr.city = 'BLR';