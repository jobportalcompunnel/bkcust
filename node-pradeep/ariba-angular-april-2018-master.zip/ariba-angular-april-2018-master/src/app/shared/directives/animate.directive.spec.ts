import { AnimateDirective } from './animate.directive';

describe('AnimateDirective', () => {
  it('should create an instance', () => {
    const directive = new AnimateDirective();
    expect(directive).toBeTruthy();
  });
});
