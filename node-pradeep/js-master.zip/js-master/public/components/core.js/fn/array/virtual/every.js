require('../../../modules/es6.array.every');
module.exports = require('../../../modules/_entry-virtual')('Array').every;