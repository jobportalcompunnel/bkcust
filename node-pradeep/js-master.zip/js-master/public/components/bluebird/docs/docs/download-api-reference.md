---
id: download-api-reference
title: Download API Reference
---

In order to use the documentation offline (without a stable internet connection).

 - Go to [the GitHub Pages Branch `gh-pages`](https://github.com/petkaantonov/bluebird/tree/gh-pages).
 - Click "Clone Or Download".
 - Click "Download Zip".
 - Extract the contents of the zip and open the "docs" folder.
 - Open `api-reference.html` which is the documentation root.
