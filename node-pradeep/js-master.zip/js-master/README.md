# nodejs
Node.js, JavaScript Starter


First clone the repository

>  git clone https://github.com/nodesense/js

> cd js

install all the packages needed for training

> npm install


