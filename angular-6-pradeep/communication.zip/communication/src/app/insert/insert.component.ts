import { Component, OnInit,EventEmitter,Output } from '@angular/core';

@Component({
  selector: 'app-insert',
  templateUrl: './insert.component.html',
  styleUrls: ['./insert.component.css']
})
export class InsertComponent implements OnInit {
serverName:string = '';
 @Output() insert = new EventEmitter();

  constructor() { }

  ngOnInit() {
  }
  insertHandler(){
    //console.log(this.serverName);
    this.insert.emit({
      name:this.serverName
    });
  }

}
