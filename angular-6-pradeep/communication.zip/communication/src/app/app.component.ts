import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  servers = [
    {name:'Production Server'},
    {name:'Web Server'},
    {name:'Development Server'},
    {name:'Testing Server'}
  ];
  insertEventHandler(event){
    this.servers.push({name:event.name});
  }
}
