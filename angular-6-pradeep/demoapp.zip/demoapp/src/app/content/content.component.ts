import { Component, OnInit } from '@angular/core';
import {ServersService} from '../servers.service';
@Component({
  selector: 'app-content',
  templateUrl: './content.component.html',
  styleUrls: ['./content.component.css']
})
export class ContentComponent implements OnInit {
  servers;
  constructor(private serversservice:ServersService) { 
  this.servers = serversservice.getServers();
  }

  ngOnInit() {
  }

}
