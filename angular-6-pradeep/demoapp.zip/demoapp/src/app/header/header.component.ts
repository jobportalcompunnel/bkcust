import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  title:string = 'This is a Header Component';
  str:string = 'hello Para';
  constructor() { }

  ngOnInit() {
  }
  clickHandler(){
    alert('Hello World!!!');
  }

}
