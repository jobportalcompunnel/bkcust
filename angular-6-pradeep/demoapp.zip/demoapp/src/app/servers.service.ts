import { Injectable } from '@angular/core';

/* @Injectable({
  providedIn: 'root'
}) */
export class ServersService {
  private servers = [
    {name:'Production Server'},
    {name:'Development Server'},
    {name:'Testing Server'},
    {name:'File Server'}
  ];
  constructor() { }

  getServers(){
    return this.servers;
  }
}
