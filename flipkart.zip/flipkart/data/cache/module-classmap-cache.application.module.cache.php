<?php
return array (
  'Helloworld\\Module' => 'D:\\zend\\flipkart\\module\\Helloworld\\Module.php',
);